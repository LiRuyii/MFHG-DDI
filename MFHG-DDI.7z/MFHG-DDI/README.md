Requirements
python (tested on version 3.7.11)
pytorch (tested on version 1.6.0)
torch-geometric (tested on version 2.0.2)
numpy (tested on version 1.21.2)
scikit-learn(tested on version 1.0.2)

DATA
All data used in the study are from public resources.
DrugBank is available at https://go.drugbank.com/.
Pubchem is available at https://pubchem.ncbi.nlm.nih.gov/.