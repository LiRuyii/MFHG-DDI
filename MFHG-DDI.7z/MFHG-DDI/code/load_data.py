import csv
import torch
import random
import numpy as np
import train



def read_csv(path):
    with open(path, 'r', newline='') as csv_file:
        reader = csv.reader(csv_file)
        data = []
        data += [[float(i) for i in row] for row in reader]
        return torch.Tensor(data)


# 得到每条边的索引
def get_edge_index(matrix):
    edge_index = [[], []]
    for i in range(matrix.size(0)):
        for j in range(matrix.size(1)):
            if matrix[i][j] != 0:
                edge_index[0].append(i)
                edge_index[1].append(j)
    return torch.LongTensor(edge_index)


def dataset(args):
    dataset = dict()

    merged_matrix = read_csv('Heterogeneous network.csv')
    ddi_matrix = merged_matrix[:, :548]
    drug_similarity_matrix = merged_matrix[:, 548:]


    ddi_edge_index = get_edge_index(ddi_matrix)

    data_matrix = drug_similarity_matrix

    dataset['ddi_matrix'] = {'data_matrix': torch.Tensor(data_matrix), 'edges': ddi_edge_index}


    zero_index = []
    one_index = []


    for i in range(ddi_matrix.size(0)):
        for j in range(ddi_matrix.size(1)):
            if ddi_matrix[i][j] < 1:
                zero_index.append([i, j, 0])
            if ddi_matrix[i][j] >= 1:
                one_index.append([i, j, 1])


    ddi_pairs = random.sample(zero_index, len(one_index)) + one_index

    return dataset, ddi_pairs


# 特征表示，处理药物-药物相互作用
def feature_representation(model, args, dataset):
    model.cuda()
    optimizer = torch.optim.Adam(model.parameters(), lr=0.001)
    model = train(model, dataset, optimizer, args)
    model.eval()

    with torch.no_grad():
        score, drug_fea = model(dataset)
    drug_fea = drug_fea.cpu().detach().numpy()

    return score, drug_fea


# 生成新的数据，预测药物-药物相互作用
def new_dataset(drug_fea, ddi_pairs):
    unknown_pairs = []
    known_pairs = []

    for pair in ddi_pairs:
        if pair[2] == 1:
            known_pairs.append(pair[:2])
        if pair[2] == 0:
            unknown_pairs.append(pair[:2])

    print("--------------------")
    print(drug_fea.shape)
    print("--------------------")
    print(len(unknown_pairs), len(known_pairs))

    nega_list = []
    for i in range(len(unknown_pairs)):

        nega = drug_fea[unknown_pairs[i][0], :].tolist() + drug_fea[unknown_pairs[i][1], :].tolist() + [0, 1]
        nega_list.append(nega)

    posi_list = []
    for j in range(len(known_pairs)):
        posi = drug_fea[known_pairs[j][0], :].tolist() + drug_fea[known_pairs[j][1], :].tolist() + [1, 0]
        posi_list.append(posi)


    samples = posi_list + nega_list
    random.shuffle(samples)


    samples = np.array(samples)
    return samples


# 定义关联矩阵，处理药物-药物的相互作用
def D_Dmatix(ddi_pairs, trainindex, testindex):

    d_dmatix = np.zeros((548, 548))


    for i in trainindex:
        if ddi_pairs[i][2] == 1:
            d_dmatix[ddi_pairs[i][0]][ddi_pairs[i][1]] = 1
            d_dmatix[ddi_pairs[i][1]][ddi_pairs[i][0]] = 1

    dataset = dict()
    dd_data = []
    dd_data += [[float(i) for i in row] for row in d_dmatix]
    dd_data = torch.Tensor(dd_data)
    dataset['d_d'] = dd_data

    train_ddi_pairs = []
    test_ddi_pairs = []

    for m in trainindex:
        train_ddi_pairs.append(ddi_pairs[m])

    for n in testindex:
        test_ddi_pairs.append(ddi_pairs[n])

    return dataset['d_d'], train_ddi_pairs, test_ddi_pairs




