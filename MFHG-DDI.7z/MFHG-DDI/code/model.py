import torch
from torch import nn
from torch_geometric.nn import GCNConv, GATConv

torch.backends.cudnn.enabled = False

class GCN(nn.Module):
    def __init__(self, args):
        """
        模型构造函数
        :param args: Arguments object.
        """
        super(GCN, self).__init__()
        self.args = args

        self.gcn_drug1_f = GCNConv(self.args.fdrug, 128)

        self.gat_drug1_f = GATConv(128, 128, heads=4, concat=False, edge_dim=1)

        self.gcn_drug2_f = GCNConv(128, 128)

        self.cnn_drug = nn.Conv1d(in_channels=3,
                                  out_channels=self.args.out_channels,
                                  kernel_size=384,
                                  stride=1,
                                  bias=True)

        # 全局平均池化层
        self.gap = nn.AdaptiveAvgPool1d(1)

        self.sigmoid = nn.Sigmoid()

    def forward(self, data):

        x_drug = data['ddi_matrix']['data_matrix'].cuda()
        edge_index = data['ddi_matrix']['edges'].cuda()

        x_drug_f1 = torch.relu(self.gcn_drug1_f(x_drug, edge_index))

        x_drug_att = torch.relu(self.gat_drug1_f(x_drug_f1, edge_index))

        x_drug_f2 = torch.relu(self.gcn_drug2_f(x_drug_att, edge_index))

        X_drug = torch.cat((x_drug_f1, x_drug_att, x_drug_f2), dim=1).t()

        X_drug = X_drug.view(3, 128, -1)

        drug_fea = self.cnn_drug(X_drug)

        drug_fea = self.gap(drug_fea).view(self.args.out_channels, self.args.drug_number).t()

        prediction = self.sigmoid(drug_fea.mm(drug_fea.t()))

        return prediction, drug_fea












