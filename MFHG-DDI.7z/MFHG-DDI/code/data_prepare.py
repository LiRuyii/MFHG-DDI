import numpy as np
import torch


def jaccard_similarity(x, y):

    intersection = np.logical_and(x, y).sum()
    union = np.logical_or(x, y).sum()
    return intersection / union if union != 0 else 0

# 根据药物特征矩阵计算杰卡德相似度矩阵
def calculate_jaccard_matrix(feature_matrix):
    num_drugs = feature_matrix.shape[0]
    jaccard_matrix = np.zeros((num_drugs, num_drugs))

    for i in range(num_drugs):
        for j in range(num_drugs):
            jaccard_matrix[i][j] = jaccard_similarity(feature_matrix[i], feature_matrix[j])

    return jaccard_matrix


# 多个相似度矩阵相加并求平均
def average_similarity_matrices(matrices):
    total_matrix = np.zeros_like(matrices[0])


    for matrix in matrices:
        total_matrix += matrix


    avg_matrix = total_matrix / len(matrices)

    return avg_matrix
