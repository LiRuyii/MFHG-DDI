import numpy as np
import torch

# 训练过程
def train(model, train_data, optimizer, opt):
    model.train()
    for epoch in range(0, opt.epoch):
        model.zero_grad()
        score, _ = model(train_data)
        loss_fn = torch.nn.BCELoss(reduction='mean')
        loss = loss_fn(score, train_data['c_d'].cuda())
        loss.backward()
        optimizer.step()
        print(f'Epoch: {epoch}, Loss: {loss.item()}')

    score = score.detach().cpu().numpy()


    np.savetxt('DDI-results.txt', score * -1 * 0.01, fmt='%0.05f', delimiter=',')

    return model