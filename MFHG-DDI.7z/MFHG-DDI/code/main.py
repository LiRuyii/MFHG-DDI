import load_data
from model import GCN
from sklearn.model_selection import KFold
import evaluate
import time
import argparse
import torch , gc


def parameter_parser():
    parser = argparse.ArgumentParser(description="Run MFHG-DDI.")

    parser.add_argument("--dataset-path",
                        type=str,
                        default="Heterogeneous network.csv",
                        help="Path to the dataset.")

    parser.add_argument("--epoch",
                        type=int,
                        default=100,
                        help="Number of training epochs. Default is 10.")

    parser.add_argument("--gcn-layers",
                        type=int,
                        default=2,
                        help="Number of Graph Convolutional Layers. Default is 2.")

    parser.add_argument("--drug-number",
                        type=int,
                        default=548,
                        help="Number of drugs in the dataset. Default is 548.")

    parser.add_argument("--fdrug",
                        type=int,
                        default=128,
                        help="Drug feature dimensions. Default is 128.")

    return parser.parse_args()


def DDA(n_fold):
    args = parameter_parser()
    dataset, cd_pairs = load_data.dataset(args)
    kf = KFold(n_splits=n_fold, shuffle=True)
    gcn_model = GCN(args).cuda()
    optimizer = torch.optim.Adam(gcn_model.parameters(), lr=0.001)

    ave_acc, ave_prec, ave_sens, ave_f1_score, ave_mcc, ave_auc, ave_auprc = 0, 0, 0, 0, 0, 0, 0


    localtime = time.asctime(time.localtime(time.time()))

    # 将得分保存到指定地址
    with open('results.txt', 'a') as f:
        f.write('\n' + 'time:\t' + str(localtime) + "\n")

        for train_index, test_index in kf.split(cd_pairs):

            d_dmatix, train_dd_pairs, test_dd_pairs = load_data.D_Dmatix(cd_pairs, train_index, test_index)
            dataset['d_d'] = d_dmatix


            gcn_model.train()
            optimizer.zero_grad()
            score, drug_fea = gcn_model(dataset)
            loss_fn = torch.nn.BCELoss()
            loss = loss_fn(score, dataset['d_d'].cuda())
            loss.backward()
            optimizer.step()

            test_dataset = load_data.new_dataset(drug_fea.cpu().detach().numpy(), test_dd_pairs)
            X_test, y_test = test_dataset[:, :-2], test_dataset[:, -2:]


            gcn_model.eval()
            with torch.no_grad():
                score_test, _ = gcn_model(dataset)
                y_pred = score_test.cpu().numpy()


            y_pred_binary = (y_pred > 0.5).astype(int).flatten()

            # 计算性能指标
            tp, fp, tn, fn, acc, prec, sens, f1_score, MCC, AUC, AUPRC = evaluate.calculate_performace(
                len(y_pred_binary), y_pred_binary, y_pred.flatten(), y_test[:, 0]
            )
            print('GCN Model: \n  Acc = \t', acc, '\n  prec = \t', prec, '\n  sens = \t', sens, '\n  f1_score = \t', f1_score,
                  '\n  MCC = \t', MCC, '\n  AUC = \t', AUC, '\n  AUPRC = \t', AUPRC)


            f.write('GCN Model: \n  Acc = \t' + str(acc) + '\t  prec = \t' + str(prec) + '\t  sens = \t' + str(sens) + '\t  f1_score = \t' + str(f1_score) + '\t  MCC = \t' + str(MCC) + '\t  AUC = \t' + str(AUC) + '\t  AUPRC = \t' + str(AUPRC) + '\n')


            ave_acc += acc
            ave_prec += prec
            ave_sens += sens
            ave_f1_score += f1_score
            ave_mcc += MCC
            ave_auc += AUC
            ave_auprc += AUPRC


        ave_acc /= n_fold
        ave_prec /= n_fold
        ave_sens /= n_fold
        ave_f1_score /= n_fold
        ave_mcc /= n_fold
        ave_auc /= n_fold
        ave_auprc /= n_fold


        print('Final: \t  Acc = \t' + str(ave_acc) + '\t  prec = \t' + str(ave_prec) + '\t  sens = \t' + str(ave_sens) + '\t  f1_score = \t' + str(ave_f1_score) + '\t  MCC = \t' + str(ave_mcc) + '\t  AUC = \t' + str(ave_auc) + '\t  AUPRC = \t' + str(ave_auprc) + '\n')
        f.write('Final: \t  Acc = \t' + str(ave_acc) + '\t  prec = \t' + str(ave_prec) + '\t  sens = \t' + str(ave_sens) + '\t  f1_score = \t' + str(ave_f1_score) + '\t  MCC = \t' + str(ave_mcc) + '\t  AUC = \t' + str(ave_auc) + '\t  AUPRC = \t' + str(ave_auprc) + '\n')


        gc.collect()
        torch.cuda.empty_cache()

if __name__ == "__main__":

    n_fold = 5
    for i in range(100):
        DDA(n_fold)
